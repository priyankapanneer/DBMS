<?php
session_start();
include 'db.php';

if (!isset($_SESSION['employee_id'])) {
    http_response_code(403);
    echo "Unauthorized";
    exit();
}

$emp_id = $_SESSION['employee_id'];
$query = "UPDATE notifications SET status = 'read' WHERE employee_id = '$emp_id' AND status = 'unread'";
mysqli_query($conn, $query);

echo "Notifications cleared.";
?>
