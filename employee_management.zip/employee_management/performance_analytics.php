<?php
include 'db.php';

function calculate_performance($employee_id) {
    // Get the total attendance and leave data
    $attendanceQuery = "SELECT COUNT(*) AS total_days, 
                        SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS days_present, 
                        SUM(CASE WHEN status = 'Late' THEN 1 ELSE 0 END) AS late_days
                        FROM attendance WHERE employee_id = $employee_id";
    $attendanceResult = mysqli_fetch_assoc(mysqli_query($conn, $attendanceQuery));

    $leaveQuery = "SELECT COUNT(*) AS total_leaves, 
                        SUM(CASE WHEN leave_type = 'Sick' AND status = 'Approved' THEN 1 ELSE 0 END) AS sick_leaves,
                        SUM(CASE WHEN leave_type = 'Casual' AND status = 'Approved' THEN 1 ELSE 0 END) AS casual_leaves
                        FROM leave_requests WHERE employee_id = $employee_id";
    $leaveResult = mysqli_fetch_assoc(mysqli_query($conn, $leaveQuery));

    $overtimeQuery = "SELECT SUM(overtime_hours) AS total_overtime 
                      FROM attendance WHERE employee_id = $employee_id";
    $overtimeResult = mysqli_fetch_assoc(mysqli_query($conn, $overtimeQuery));

    // Calculate attendance score (percentage of days attended)
    $attendanceScore = ($attendanceResult['days_present'] / $attendanceResult['total_days']) * 100;

    // Calculate leave score (percentage of unplanned leaves)
    $unplannedLeaves = $leaveResult['total_leaves'] - ($leaveResult['sick_leaves'] + $leaveResult['casual_leaves']);
    $leaveScore = ($unplannedLeaves / $leaveResult['total_leaves']) * 100;

    // Calculate overtime score (how much overtime worked)
    $standardHours = 160;  // Assuming 40 hours/week for a month
    $overtimeScore = ($overtimeResult['total_overtime'] / $standardHours) * 100;

    // Calculate punctuality score (percentage of on-time check-ins)
    $punctualityQuery = "SELECT COUNT(*) AS total_checkins, 
                                SUM(CASE WHEN status = 'Present' AND TIMESTAMPDIFF(MINUTE, check_in_time, '09:00:00') <= 0 THEN 1 ELSE 0 END) AS on_time_checkins
                                FROM attendance WHERE employee_id = $employee_id";
    $punctualityResult = mysqli_fetch_assoc(mysqli_query($conn, $punctualityQuery));
    $punctualityScore = ($punctualityResult['on_time_checkins'] / $punctualityResult['total_checkins']) * 100;

    // Combine all scores into a final performance score (simple average in this case)
    $finalPerformanceScore = ($attendanceScore + $leaveScore + $overtimeScore + $punctualityScore) / 4;

    return [
        'attendance_score' => round($attendanceScore, 2),
        'leave_score' => round($leaveScore, 2),
        'overtime_score' => round($overtimeScore, 2),
        'punctuality_score' => round($punctualityScore, 2),
        'final_performance_score' => round($finalPerformanceScore, 2)
    ];
}

$employee_id = 1; // Example employee ID
$performanceData = calculate_performance($employee_id);

echo "<h2>Employee Performance Analytics</h2>";
echo "<p>Attendance Score: {$performanceData['attendance_score']}%</p>";
echo "<p>Leave Score: {$performanceData['leave_score']}%</p>";
echo "<p>Overtime Score: {$performanceData['overtime_score']}%</p>";
echo "<p>Punctuality Score: {$performanceData['punctuality_score']}%</p>";
echo "<p>Final Performance Score: {$performanceData['final_performance_score']}%</p>";
?>
