<?php
session_start();
if (!isset($_SESSION['employee_id']) || $_SESSION['role'] !== 'employee') {
    header("Location: login.php");
    exit();
}
include 'db.php';
$emp_id = $_SESSION['employee_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            background-color: #2a3a55;
            color: #f1f1f1;
            display: flex;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .light-theme {
            background-color: #f5f5f5;
            color: #333;
        }

        .sidebar {
            width: 240px;
            background-color: #1c2a3a;
            min-height: 100vh;
            padding-top: 30px;
            position: fixed;
            top: 0;
            left: 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.3);
            transition: background-color 0.3s;
        }

        .light-theme .sidebar {
            background-color: #ffffff;
        }

        .sidebar a {
            display: block;
            padding: 15px 25px;
            color: #f1f1f1;
            text-decoration: none;
            font-weight: 500;
            transition: background 0.3s, color 0.3s;
        }

        .light-theme .sidebar a {
            color: #333;
        }

        .sidebar a:hover {
            background-color: #334d6e;
        }

        .light-theme .sidebar a:hover {
            background-color: #dddddd;
        }

        .sidebar .logout {
            background-color: #dc3545;
            margin-top: 20px;
        }

        .main-content {
            margin-left: 240px;
            padding: 40px;
            width: 100%;
            box-sizing: border-box;
            transition: background-color 0.3s, color 0.3s;
        }

        h2 {
            color: #00aaff;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .notification-bell {
            font-size: 26px;
            cursor: pointer;
            position: relative;
            color: #00aaff;
            margin-right: 20px;
        }

        .notification-badge {
            position: absolute;
            top: -5px;
            right: -10px;
            background-color: red;
            color: white;
            font-size: 12px;
            padding: 3px 7px;
            border-radius: 50%;
        }

        .notification-box {
            position: absolute;
            top: 60px;
            right: 80px;
            width: 300px;
            background-color: #fff;
            color: #000;
            border-radius: 8px;
            box-shadow: 0 0 12px rgba(0,0,0,0.2);
            display: none;
            z-index: 999;
            padding: 15px;
            max-height: 300px;
            overflow-y: auto;
        }

        .notification-item {
            margin-bottom: 10px;
        }

        .notification-item p {
            margin: 0;
        }

        .notification-item small {
            color: #555;
        }

        .theme-icon {
            font-size: 26px;
            cursor: pointer;
            color: #00aaff;
            margin-left: 15px;
        }

        select, button {
            padding: 10px;
            border-radius: 6px;
            font-size: 14px;
            margin-top: 15px;
        }

        button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .light-theme .notification-box {
            background-color: #ffffff;
            color: #000000;
        }

        .light-theme h2 {
            color: #007bff;
        }

        .light-theme button {
            background-color: #007bff;
            color: white;
        }

        .light-theme button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <a href="checkin.php">🕒 Check In</a>
        <a href="checkout.php">🕔 Check Out</a>
        <a href="leave_request.php">📆 Submit Leave</a>
        <a href="my_leave_history.php">📄 Leave History</a>
        <a href="employee_profile.php">👤 My Profile</a>
        <a href="logout.php" class="logout">🚪 Logout</a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="top-bar">
            <h2>Welcome, <?= htmlspecialchars($_SESSION['name']); ?> 👋</h2>
            <div style="display: flex; align-items: center;">
                <div class="notification-bell" onclick="toggleNotifications()">
                    🔔
                    <?php
                    $count_query = mysqli_query($conn, "SELECT COUNT(*) AS unread_count FROM notifications WHERE employee_id = '$emp_id' AND status = 'unread'");
                    $count_row = mysqli_fetch_assoc($count_query);
                    $unread_count = $count_row['unread_count'];
                    if ($unread_count > 0) {
                        echo "<span class='notification-badge'>{$unread_count}</span>";
                    }
                    ?>
                </div>
                <div class="theme-icon" onclick="toggleTheme()" id="theme-icon">🌙</div>
            </div>
        </div>

        <div id="notification-box" class="notification-box">
            <div style="text-align:right;">
                <button onclick="clearNotifications()">🧹 Clear All</button>
            </div>
            <hr>
            <?php
            $result = mysqli_query($conn, "SELECT * FROM notifications WHERE employee_id = '$emp_id' AND status = 'unread' ORDER BY created_at DESC");
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<div class='notification-item'>";
                    echo "<p>" . htmlspecialchars($row['message']) . "</p>";
                    echo "<small>" . $row['created_at'] . "</small>";
                    echo "</div><hr>";
                }
            } else {
                echo "<p>No new notifications.</p>";
            }
            ?>
        </div>

        <!-- CSV Full -->
        <form action="export_my_attendance.php" method="GET">
            <button type="submit">📥 Download Full Attendance CSV</button>
        </form>

        <!-- CSV Filtered -->
        <form action="export_my_attendance.php" method="GET">
            <label for="month">Month:</label>
            <select name="month" id="month">
                <?php for ($m = 1; $m <= 12; $m++): ?>
                    <option value="<?= str_pad($m, 2, '0', STR_PAD_LEFT) ?>">
                        <?= date("F", mktime(0, 0, 0, $m, 1)) ?>
                    </option>
                <?php endfor; ?>
            </select>

            <label for="year">Year:</label>
            <select name="year" id="year">
                <?php for ($y = 2023; $y <= date("Y"); $y++): ?>
                    <option value="<?= $y ?>"><?= $y ?></option>
                <?php endfor; ?>
            </select>
            <button type="submit">📥 Download Filtered CSV</button>
        </form>
    </div>

    <script>
        let isLight = false;

        function toggleNotifications() {
            const box = document.getElementById("notification-box");
            box.style.display = (box.style.display === "block") ? "none" : "block";
        }

        function clearNotifications() {
            fetch('clear_notifications.php')
                .then(response => response.text())
                .then(() => {
                    document.getElementById("notification-box").innerHTML = "<p>No new notifications.</p>";
                });
        }

        function toggleTheme() {
            const body = document.body;
            isLight = !isLight;

            if (isLight) {
                body.classList.add('light-theme');
                document.getElementById("theme-icon").textContent = "☀️";
            } else {
                body.classList.remove('light-theme');
                document.getElementById("theme-icon").textContent = "🌙";
            }
        }
    </script>
</body>
</html>
