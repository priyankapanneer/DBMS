<?php
session_start();
include 'db.php';

if (!isset($_SESSION['employee_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="attendance_report.csv"');

$output = fopen("php://output", "w");
fputcsv($output, ['ID', 'Employee', 'Date', 'Check In', 'Check Out']);

$query = mysqli_query($conn, "
    SELECT a.*, e.name FROM attendance a 
    JOIN employees e ON a.employee_id = e.employee_id  -- Updated to use employee_id
");

while ($row = mysqli_fetch_assoc($query)) {
    fputcsv($output, [
        $row['id'],
        $row['name'],
        $row['date'],
        $row['check_in'],
        $row['check_out']
    ]);
}

fclose($output);
exit();
