<?php
include 'db.php';
session_start();

// Handle Add Employee
if (isset($_POST['add_employee'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $doj = $_POST['date_of_joining'];

    $stmt = $conn->prepare("INSERT INTO employees (name, email, role, password, date_of_joining) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $role, $password, $doj);
    $stmt->execute();
    $stmt->close();
    header("Location: admin_manage_employees.php");
    exit();
}

// Handle Delete
if (isset($_GET['delete'])) {
    $employee_id = intval($_GET['delete']);
    $conn->query("DELETE FROM employees WHERE employee_id = $employee_id");
    header("Location: admin_manage_employees.php");
    exit();
}

// Handle Update
if (isset($_POST['update_employee'])) {
    $employee_id = $_POST['employee_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $doj = $_POST['date_of_joining'];

    $stmt = $conn->prepare("UPDATE employees SET name=?, email=?, role=?, date_of_joining=? WHERE employee_id=?");
    $stmt->bind_param("ssssi", $name, $email, $role, $doj, $employee_id);
    $stmt->execute();
    $stmt->close();
    header("Location: admin_manage_employees.php");
    exit();
}

// Fetch all employees
$result = $conn->query("SELECT * FROM employees");

// If editing, get employee data
$edit_employee = null;
if (isset($_GET['edit'])) {
    $edit_id = intval($_GET['edit']);
    $edit_result = $conn->query("SELECT * FROM employees WHERE employee_id = $edit_id");
    if ($edit_result->num_rows > 0) {
        $edit_employee = $edit_result->fetch_assoc();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Employees</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #ecf0f1;
            padding: 30px;
        }

        h2 {
            text-align: center;
            color: #2c3e50;
        }

        form {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            max-width: 600px;
            margin: 0 auto 30px auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #bdc3c7;
        }

        button {
            background: #16a085;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        .cancel-btn {
            background: #7f8c8d;
            margin-left: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background: #34495e;
            color: white;
        }

        .delete-btn {
            background-color: #e74c3c;
            color: white;
            padding: 5px 12px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
        }

        .edit-btn {
            background-color: #2980b9;
            color: white;
            padding: 5px 12px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            margin-right: 5px;
        }
    </style>
</head>
<body>

<h2>🛠️ Manage Employees</h2>

<!-- Add / Edit Employee Form -->
<form method="POST" action="">
    <h3><?= $edit_employee ? '✏️ Edit Employee' : '➕ Add New Employee' ?></h3>
    <input type="hidden" name="employee_id" value="<?= $edit_employee['employee_id'] ?? '' ?>">
    <input type="text" name="name" placeholder="Employee Name" required value="<?= $edit_employee['name'] ?? '' ?>">
    <input type="email" name="email" placeholder="Email Address" required value="<?= $edit_employee['email'] ?? '' ?>">
    <select name="role" required>
        <option value="">--Select Role--</option>
        <option value="Employee" <?= isset($edit_employee['role']) && $edit_employee['role'] === 'Employee' ? 'selected' : '' ?>>Employee</option>
        <option value="Admin" <?= isset($edit_employee['role']) && $edit_employee['role'] === 'Admin' ? 'selected' : '' ?>>Admin</option>
    </select>
    <input type="date" name="date_of_joining" required value="<?= $edit_employee['date_of_joining'] ?? '' ?>">
    <?php if ($edit_employee): ?>
        <button type="submit" name="update_employee">💾 Update</button>
        <a href="admin_manage_employees.php" class="cancel-btn" style="text-decoration:none;"><button type="button" class="cancel-btn">Cancel</button></a>
    <?php else: ?>
        <input type="password" name="password" placeholder="Temporary Password" required>
        <button type="submit" name="add_employee">Add Employee</button>
    <?php endif; ?>
</form>

<!-- Employee Table -->
<table>
    <tr>
        <th>#</th>
        <th>Name</th>
        <th>Email</th>
        <th>Role</th>
        <th>Date of Joining</th>
        <th>Actions</th>
    </tr>
    <?php
    $i = 1;
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$i}</td>
                <td>{$row['name']}</td>
                <td>{$row['email']}</td>
                <td>{$row['role']}</td>
                <td>{$row['date_of_joining']}</td>
                <td>
                    <a class='edit-btn' href='admin_manage_employees.php?edit={$row['employee_id']}'>Edit</a>
                    <a class='delete-btn' href='admin_manage_employees.php?delete={$row['employee_id']}' onclick=\"return confirm('Are you sure?')\">Delete</a>
                </td>
              </tr>";
        $i++;
    }
    ?>
</table>

</body>
</html>
