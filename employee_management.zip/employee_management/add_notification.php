<?php
include 'db.php';

function addNotification($employee_id, $message) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO notifications (employee_id, message) VALUES (?, ?)");
    $stmt->bind_param("is", $employee_id, $message);
    $stmt->execute();
}
?>
