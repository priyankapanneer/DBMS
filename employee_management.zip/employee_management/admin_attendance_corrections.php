<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

// Fetch all attendance correction requests
$query = "SELECT * FROM attendance_corrections";
$result = mysqli_query($conn, $query);

// Update the correction status
if (isset($_GET['action']) && isset($_GET['id'])) {
    $correction_id = $_GET['id'];
    $action = $_GET['action'];

    if ($action == 'approve') {
        // Approve the correction request
        $update_query = "UPDATE attendance_corrections SET status = 'approved' WHERE id = $correction_id";
        mysqli_query($conn, $update_query);
    } elseif ($action == 'reject') {
        // Reject the correction request
        $update_query = "UPDATE attendance_corrections SET status = 'rejected' WHERE id = $correction_id";
        mysqli_query($conn, $update_query);
    }
    header("Location: admin_attendance_corrections.php"); // Refresh the page
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Attendance Correction Requests</title>
    <style>
        body {
            font-family: 'Segoe UI';
            background: #e3f2fd;
            text-align: center;
            padding: 50px;
        }

        h2 {
            color: #0d47a1;
        }

        .correction-table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        .correction-table th, .correction-table td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: left;
        }

        .correction-table th {
            background-color: #007bff;
            color: white;
        }

        .button {
            padding: 6px 12px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            color: white;
        }

        .approve {
            background-color: #28a745;
        }

        .reject {
            background-color: #dc3545;
        }

        .button:hover {
            opacity: 0.8;
        }

        .logout {
            margin-top: 40px;
            display: inline-block;
            background: #d32f2f;
            color: white;
            padding: 10px 25px;
            border-radius: 8px;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <h2>Manage Attendance Correction Requests</h2>

    <table class="correction-table">
        <thead>
            <tr>
                <th>Employee ID</th>
                <th>Correction Date</th>
                <th>Correction Reason</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo $row['employee_id']; ?></td>
                    <td><?php echo $row['correction_date']; ?></td>
                    <td><?php echo $row['correction_reason']; ?></td>
                    <td><?php echo $row['status']; ?></td>
                    <td>
                        <?php if ($row['status'] == 'pending'): ?>
                            <a href="admin_attendance_corrections.php?action=approve&id=<?php echo $row['id']; ?>" class="button approve">Approve</a>
                            <a href="admin_attendance_corrections.php?action=reject&id=<?php echo $row['id']; ?>" class="button reject">Reject</a>
                        <?php else: ?>
                            <span>Completed</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <a class="logout" href="logout.php">🚪 Logout</a>
</body>
</html>
