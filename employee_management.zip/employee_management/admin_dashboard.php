<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            display: flex;
            background: #2c3e50; /* Stormy dark blue-gray */
        }

        /* Sidebar Styles */
        .sidebar {
            background-color: #34495e; /* Darker stormy gray */
            width: 250px;
            height: 100vh;
            padding-top: 40px;
            position: fixed;
        }

        .sidebar h2 {
            color: #ecf0f1; /* Light gray for the header */
            text-align: center;
            margin-bottom: 30px;
        }

        .sidebar a {
            display: block;
            color: #bdc3c7; /* Light gray for links */
            padding: 15px;
            text-decoration: none;
            font-weight: bold;
            margin: 10px 0;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #16a085; /* Soft teal */
            color: white;
        }

        /* Main Content Area */
        .main-content {
            margin-left: 260px;
            padding: 30px;
            background-color: #ecf0f1; /* Light background for the main area */
            height: 100vh;
            width: calc(100% - 250px);
            overflow: auto;
        }

        .card-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
            margin-top: 40px;
        }

        .card {
            background: white;
            padding: 25px 40px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
            width: 260px;
            text-align: center;
        }

        .card:hover {
            transform: scale(1.05);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
        }

        a {
            text-decoration: none;
            color: #2980b9; /* Stormy blue for text links */
            font-weight: bold;
            display: block;
        }

        .logout {
            margin-top: 40px;
            display: inline-block;
            background: #e74c3c; /* Red for logout */
            color: white;
            padding: 10px 25px;
            border-radius: 8px;
            text-decoration: none;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Admin Dashboard</h2>
        <a href="admin_view_employees.php">👨‍💼 View Employees</a>
        <a href="admin_manage_employees.php">🛠️ Manage Employees</a>
        <a href="admin_leave_requests.php">📄 Manage Leave Requests</a>
        <a href="admin_attendance_records.php">📅 View Attendance Records</a>
        <a href="admin_dashboard_analytics.php">📊 Dashboard Analytics</a>
        <a href="admin_export_attendance.php">📁 Export Attendance as CSV</a>
        <a href="admin_notifications.php">🔔 View Notifications</a>
        <!-- New card for Attendance Correction Requests -->
        <a href="admin_employee_performance.php">📊 Employee Performance</a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <h2>Welcome, Admin</h2>

        <a class="logout" href="logout.php">🚪 Logout</a>
    </div>

</body>
</html>
