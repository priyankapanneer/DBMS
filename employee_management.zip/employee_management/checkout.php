<?php
session_start();
include 'db.php';

if (!isset($_SESSION['employee_id']) || $_SESSION['role'] !== 'employee') {
    header("Location: login.php");
    exit();
}

date_default_timezone_set('Asia/Kolkata');
$employee_id = $_SESSION['employee_id'];
$date = date('Y-m-d');
$check_out_time = date('Y-m-d H:i:s');

// Fetch today's attendance record
$query = "SELECT * FROM attendance WHERE employee_id='$employee_id' AND date='$date'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_assoc($result);

    if (empty($row['check_out'])) {
        $check_in_time = $row['check_in'];
        if (!empty($check_in_time)) {
            $start = strtotime($check_in_time);
            $end = strtotime($check_out_time);

            if ($end > $start) {
                $diff = $end - $start;
                $working_hours = gmdate("H:i:s", $diff);

                $update = "UPDATE attendance 
                           SET check_out='$check_out_time', working_hours='$working_hours', status='Present' 
                           WHERE employee_id='$employee_id' AND date='$date'";

                if (mysqli_query($conn, $update)) {
                    // Fetch total working hours for the employee
                    $sumQuery = "SELECT SEC_TO_TIME(SUM(TIME_TO_SEC(working_hours))) AS total_hours 
                                 FROM attendance 
                                 WHERE employee_id='$employee_id' AND working_hours IS NOT NULL";
                    $sumResult = mysqli_query($conn, $sumQuery);
                    $total_hours = "00:00:00"; // Default value if no previous working hours

                    if ($sumResult && mysqli_num_rows($sumResult) == 1) {
                        $sumRow = mysqli_fetch_assoc($sumResult);
                        $total_hours = $sumRow['total_hours'];
                    }

                    $status = "success";
                    $message = "✅ Checked out successfully at <strong>$check_out_time</strong><br>
                                🕒 Today's Working Hours: <strong>$working_hours</strong><br>
                                📊 Total Working Hours: <strong>$total_hours</strong>";
                } else {
                    $status = "error";
                    $message = "❌ Error during check-out. Please try again.";
                }
            } else {
                $status = "error";
                $message = "❌ Invalid time: Check-out is earlier than check-in.";
            }
        } else {
            $status = "error";
            $message = "❌ Check-in time missing. Please contact admin.";
        }
    } else {
        $status = "warning";
        $message = "⚠️ You have already checked out today at <strong>" . $row['check_out'] . "</strong>";
    }
} else {
    $status = "warning";
    $message = "⚠️ You must check in before checking out.";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Check Out</title>
    <style>
        :root {
            --bg-light: #f5f9ff;
            --bg-dark: #1e1e2f;
            --box-light: #ffffff;
            --box-dark: #2e2e40;
            --text-light: #000;
            --text-dark: #f0f0f0;
        }

        [data-theme="dark"] {
            background-color: var(--bg-dark);
            color: var(--text-dark);
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background: var(--bg-light);
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: 0.3s ease;
        }

        .box {
            background: var(--box-light);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 420px;
            max-width: 90%;
            transition: 0.3s;
        }

        [data-theme="dark"] .box {
            background: var(--box-dark);
        }

        /* Text color consistency */
        .success { 
            color: #28a745; /* Green (consistent with check-in) */
        }
        .warning { 
            color: #ffc107; /* Yellow (consistent with check-in) */
        }
        .error { 
            color: #dc3545; /* Red (consistent with check-in) */
        }

        a {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #333;
            font-weight: bold;
            transition: 0.2s;
        }

        [data-theme="dark"] a {
            color: #ccc;
        }

        a:hover {
            color: #007bff;
        }

        .theme-switch {
            position: absolute;
            top: 20px;
            right: 20px;
            cursor: pointer;
            background: #eee;
            border: none;
            padding: 8px 14px;
            border-radius: 25px;
            font-size: 14px;
            font-weight: bold;
        }

        [data-theme="dark"] .theme-switch {
            background: #444;
            color: #fff;
        }
    </style>
</head>
<body data-theme="light">
    <button class="theme-switch" onclick="toggleTheme()">🌓 Switch Theme</button>
    <div class="box">
        <h2 class="<?= $status ?>"><?= $message ?></h2>
        <a href="employee_dashboard.php">⬅ Back to Dashboard</a>
    </div>

    <script>
        function toggleTheme() {
            const body = document.body;
            const theme = body.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
            body.setAttribute('data-theme', theme);
            localStorage.setItem('theme', theme);
        }

        // Apply saved theme
        window.onload = () => {
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme) {
                document.body.setAttribute('data-theme', savedTheme);
            }
        };
    </script>
</body>
</html>
