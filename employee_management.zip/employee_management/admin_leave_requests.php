<?php
session_start();
include 'db.php';

if (!isset($_SESSION['employee_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Handle Approve/Reject + Send Notification
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['status'], $_POST['request_id'])) {
    $leave_id = $_POST['request_id'];
    $status = $_POST['status'];

    // Get employee_id, from_date for the leave
    $res = mysqli_query($conn, "SELECT employee_id, from_date FROM leave_requests WHERE id = '$leave_id'");
    $row = mysqli_fetch_assoc($res);
    $employee_id = $row['employee_id'];
    $from_date = $row['from_date'];

    // Update leave status
    mysqli_query($conn, "UPDATE leave_requests SET status='$status' WHERE id='$leave_id'");

    // Create notification
    $message = "Your leave request from $from_date has been $status.";
    mysqli_query($conn, "INSERT INTO notifications (employee_id, message, status, created_at) 
                         VALUES ('$employee_id', '$message', 'unread', NOW())");

    // Redirect back
    header("Location: admin_leave_requests.php");
    exit();
}

$result = mysqli_query($conn, "
    SELECT lr.*, e.name FROM leave_requests lr 
    JOIN employees e ON lr.employee_id = e.employee_id  -- Updated column name here
    ORDER BY lr.request_date DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Leave Requests</title>
    <style>
        body { font-family: 'Segoe UI'; background: #f0f4f7; padding: 40px; }
        h2 { text-align: center; }
        table {
            width: 95%;
            margin: auto;
            border-collapse: collapse;
            background: white;
        }
        th, td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        th { background-color: #1976d2; color: white; }
        .badge {
            padding: 5px 10px;
            border-radius: 10px;
            color: white;
        }
        .Pending { background-color: orange; }
        .Approved { background-color: green; }
        .Rejected { background-color: red; }
        form { display: inline; }
        .btn {
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            color: white;
        }
        .approve { background: #4caf50; }
        .reject { background: #f44336; }
        a.back { display: block; text-align: center; margin-top: 20px; color: #1976d2; }
    </style>
</head>
<body>
    <h2>Manage Leave Requests</h2>
    <table>
        <tr>
            <th>ID</th><th>Employee</th><th>Type</th><th>From</th><th>To</th><th>Reason</th><th>Status</th><th>Action</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['name'] ?></td>
            <td><?= $row['leave_type'] ?></td>
            <td><?= $row['from_date'] ?></td>
            <td><?= $row['to_date'] ?></td>
            <td><?= $row['reason'] ?></td>
            <td><span class="badge <?= $row['status'] ?>"><?= $row['status'] ?></span></td>
            <td>
                <?php if ($row['status'] == 'Pending'): ?>
                    <form method="POST">
                        <input type="hidden" name="request_id" value="<?= $row['id'] ?>">
                        <button class="btn approve" name="status" value="Approved">Approve</button>
                        <button class="btn reject" name="status" value="Rejected">Reject</button>
                    </form>
                <?php else: ?>
                    —
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    <a class="back" href="admin_dashboard.php">⬅ Back to Dashboard</a>
</body>
</html>
