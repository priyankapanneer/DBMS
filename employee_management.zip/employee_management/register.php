<?php
include 'db.php';
$error = "";
$success = "";

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST["name"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $role = mysqli_real_escape_string($conn, $_POST["role"]);
    $date_of_joining = mysqli_real_escape_string($conn, $_POST["date_of_joining"]);

    $check = $conn->prepare("SELECT email FROM employees WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $error = "❌ Email already registered.";
    } else {
        $query = $conn->prepare("INSERT INTO employees (name, email, password, role, date_of_joining) VALUES (?, ?, ?, ?, ?)");
        $query->bind_param("sssss", $name, $email, $password, $role, $date_of_joining);

        if ($query->execute()) {
            $success = "✅ Registered successfully!";
        } else {
            $error = "❌ Error: " . $query->error;
        }
        $query->close();
    }
    $check->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - Employee System</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

    <!-- Font Awesome (Icons) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--bg-color);
            color: var(--text-color);
            transition: all 0.3s ease;
        }

        :root {
            --bg-color: #ffffff;
            --container-bg: #f5f7fa;
            --primary: #406aff;
            --accent: #1b1f3b;
            --input-bg: #fff;
            --text-color: #1b1f3b;
        }

        body.dark {
            --bg-color: #1b1f3b;
            --container-bg: #2a2e4d;
            --primary: #64dfdf;
            --accent: #64dfdf;
            --input-bg: #1b1f3b;
            --text-color: #f5f7fa;
        }

        .form-container {
            background: var(--container-bg);
            padding: 40px;
            width: 100%;
            max-width: 450px;
            margin: 50px auto;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: var(--primary);
        }

        .input-group {
            position: relative;
            margin-bottom: 20px;
        }

        .input-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #aaa;
        }

        .input-group input,
        .input-group select {
            width: 100%;
            padding: 12px 15px 12px 42px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 14px;
            background-color: var(--input-bg);
            color: var(--text-color);
            outline: none;
        }

        .input-group input:focus,
        .input-group select:focus {
            border: 1px solid var(--accent);
            box-shadow: 0 0 8px var(--accent);
        }

        button {
            width: 100%;
            padding: 12px;
            border: none;
            background: var(--primary);
            color: white;
            font-size: 16px;
            font-weight: bold;
            border-radius: 8px;
            cursor: pointer;
        }

        button:hover {
            background: #3055d1;
        }

        .message {
            text-align: center;
            margin-top: 15px;
            font-weight: bold;
        }

        .message.success {
            color: #64df64;
        }

        .message.error {
            color: #ff6b6b;
        }

        .login-link {
            margin-top: 20px;
            text-align: center;
        }

        .login-link a {
            text-decoration: none;
            color: var(--accent);
            font-weight: 600;
        }

        .theme-toggle {
            position: absolute;
            top: 20px;
            right: 30px;
            font-size: 20px;
            cursor: pointer;
            color: var(--accent);
        }

    </style>
</head>
<body>

    <!-- Theme Toggle Button -->
    <div class="theme-toggle" onclick="toggleTheme()" title="Toggle theme">
        <i id="theme-icon" class="fas fa-moon"></i>
    </div>

    <div class="form-container">
        <h2><i class="fas fa-user-plus"></i> Register</h2>
        <form method="POST">
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="name" placeholder="Full Name" required>
            </div>

            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" placeholder="Email" required>
            </div>

            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="Password" required>
            </div>

            <div class="input-group">
                <i class="fas fa-user-tag"></i>
                <select name="role" required>
                    <option value="">Select Role</option>
                    <option value="employee">Employee</option>
                    <option value="admin">Admin</option>
                </select>
            </div>

            <div class="input-group">
                <i class="fas fa-calendar-alt"></i>
                <input type="date" name="date_of_joining" required>
            </div>

            <button type="submit">Register</button>

            <?php if ($error): ?>
                <div class="message error"><?= $error ?></div>
            <?php elseif ($success): ?>
                <div class="message success"><?= $success ?></div>
            <?php endif; ?>
        </form>

        <div class="login-link">
            Already have an account? <a href="login.php">Login here</a>
        </div>
    </div>

    <script>
        // Theme toggle with localStorage
        function toggleTheme() {
            const body = document.body;
            const icon = document.getElementById("theme-icon");
            body.classList.toggle("dark");

            if (body.classList.contains("dark")) {
                localStorage.setItem("theme", "dark");
                icon.classList.replace("fa-moon", "fa-sun");
            } else {
                localStorage.setItem("theme", "light");
                icon.classList.replace("fa-sun", "fa-moon");
            }
        }

        // Load saved theme
        window.onload = () => {
            const savedTheme = localStorage.getItem("theme");
            const body = document.body;
            const icon = document.getElementById("theme-icon");

            if (savedTheme === "dark") {
                body.classList.add("dark");
                icon.classList.replace("fa-moon", "fa-sun");
            }
        };
    </script>
</body>
</html>
