<?php
session_start();
include 'db.php';

// Notification function
function addNotification($employee_id, $message) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO notifications (employee_id, message) VALUES (?, ?)");
    $stmt->bind_param("is", $employee_id, $message);
    $stmt->execute();
}

if (!isset($_SESSION['employee_id']) || $_SESSION['role'] !== 'employee') {
    header("Location: login.php");
    exit();
}

$employee_id = $_SESSION['employee_id'];
$employee_name = $_SESSION['name'];
$success = "";
$error = "";

$month_start = date('Y-m-01');
$month_end = date('Y-m-t');

// Get total general leaves this month
$stmt = $conn->prepare("SELECT COUNT(*) FROM leave_requests WHERE employee_id = ? AND from_date BETWEEN ? AND ?");
$stmt->bind_param("iss", $employee_id, $month_start, $month_end);
$stmt->execute();
$stmt->bind_result($total_leaves_this_month);
$stmt->fetch();
$stmt->close();

// Get count of sick leaves this month
$stmt = $conn->prepare("SELECT COUNT(*) FROM leave_requests WHERE employee_id = ? AND leave_type = 'Sick' AND from_date BETWEEN ? AND ?");
$stmt->bind_param("iss", $employee_id, $month_start, $month_end);
$stmt->execute();
$stmt->bind_result($sick_leaves_this_month);
$stmt->fetch();
$stmt->close();

$general_limit = 3;
$sick_bonus = 2;
$sick_limit = $general_limit + $sick_bonus;

// Leave request submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $leave_type = $_POST['leave_type'];
    $from_date = $_POST['from_date'];
    $to_date = $_POST['to_date'];
    $reason = mysqli_real_escape_string($conn, $_POST['reason']);

    $total_requested_days = (strtotime($to_date) - strtotime($from_date)) / (60 * 60 * 24) + 1;

    if ($from_date > $to_date) {
        $error = "❌ 'From Date' cannot be later than 'To Date'.";
    } else {
        if ($leave_type === "Sick") {
            if ($sick_leaves_this_month + $total_requested_days > $sick_limit) {
                $error = "❌ You can’t take more than $sick_limit Sick leave(s) in a month.";
            } else {
                $query = "INSERT INTO leave_requests (employee_id, leave_type, from_date, to_date, reason) 
                          VALUES ('$employee_id', '$leave_type', '$from_date', '$to_date', '$reason')";
                if (mysqli_query($conn, $query)) {
                    $message = "📝 New Sick leave request submitted by $employee_name.";
                    addNotification($employee_id, $message);
                    $success = "✅ Sick Leave request submitted successfully!";
                } else {
                    $error = "❌ Something went wrong. Try again.";
                }
            }
        } else {
            if ($total_leaves_this_month + $total_requested_days > $general_limit) {
                $error = "❌ You can’t take more than $general_limit general leave(s) (Casual/Vacation) in a month.";
            } else {
                $query = "INSERT INTO leave_requests (employee_id, leave_type, from_date, to_date, reason) 
                          VALUES ('$employee_id', '$leave_type', '$from_date', '$to_date', '$reason')";
                if (mysqli_query($conn, $query)) {
                    $message = "📝 New $leave_type leave request submitted by $employee_name.";
                    addNotification($employee_id, $message);
                    $success = "✅ Leave request submitted successfully!";
                } else {
                    $error = "❌ Something went wrong. Try again.";
                }
            }
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Submit Leave Request</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f0f4fb;
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .box {
            background: #ffffff;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 420px;
            max-width: 90%;
        }

        input, select, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 10px;
            font-size: 14px;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #1e88e5;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
        }

        button:disabled {
            background-color: #cccccc;
            cursor: not-allowed;
        }

        button:hover:enabled {
            background-color: #1565c0;
        }

        .message {
            color: green;
            margin-bottom: 15px;
        }

        .error {
            color: red;
            margin-bottom: 15px;
        }

        a {
            display: block;
            text-align: center;
            margin-top: 15px;
            text-decoration: none;
            color: #1e88e5;
        }

        a:hover {
            color: #1565c0;
        }

        h2 {
            margin-bottom: 20px;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="box">
        <h2>Submit Leave Request</h2>

        <?php if ($success): ?>
            <div class="message"><?= $success ?></div>
        <?php elseif ($error): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>

        <form action="" method="POST">
            <label for="leave_type">Leave Type:</label>
            <select name="leave_type" id="leave_type" required>
                <option value="Sick">Sick</option>
                <option value="Casual">Casual</option>
                <option value="Vacation">Vacation</option>
            </select>

            <label for="from_date">From Date:</label>
            <input type="date" name="from_date" id="from_date" required>

            <label for="to_date">To Date:</label>
            <input type="date" name="to_date" id="to_date" required>

            <label for="reason">Reason:</label>
            <textarea name="reason" id="reason" rows="4" required></textarea>

            <button type="submit">Submit Leave Request</button>
        </form>

        <a href="employee_dashboard.php">⬅ Back to Dashboard</a>
    </div>
</body>
</html>
