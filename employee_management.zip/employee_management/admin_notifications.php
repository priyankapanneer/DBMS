<?php
session_start();
include 'db.php';

if (!isset($_SESSION['employee_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Fixed column reference from e.id to e.employee_id
$query = "SELECT n.id, n.message, n.created_at, e.name 
          FROM notifications n 
          JOIN employees e ON n.employee_id = e.employee_id 
          ORDER BY n.created_at DESC";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Notifications</title>
    <style>
        body { 
            font-family: 'Segoe UI'; 
            background: #f0f8ff; 
            padding: 30px; 
        }
        h2 { 
            color: #0d47a1; 
            text-align: center; 
        }
        .notification {
            background: white;
            padding: 15px;
            margin: 10px auto;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            max-width: 600px;
        }
        .notification p {
            margin: 5px 0;
        }
        .timestamp {
            font-size: 0.85em;
            color: #666;
        }
    </style>
</head>
<body>
    <h2>🔔 Admin Notifications</h2>
    <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <div class="notification">
            <p><strong><?= htmlspecialchars($row['name']) ?>:</strong> <?= htmlspecialchars($row['message']) ?></p>
            <p class="timestamp">🕒 <?= $row['created_at'] ?></p>
        </div>
    <?php endwhile; ?>
</body>
</html>
