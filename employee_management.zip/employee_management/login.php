<?php
include 'db.php';
session_start();

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];
    $role = $_POST["role"];

    $query = "SELECT * FROM employees WHERE email='$email' AND role='$role'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) === 1) {
        $user = mysqli_fetch_assoc($result);

        if (password_verify($password, $user['password'])) {
            $_SESSION['employee_id'] = $user['employee_id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['role'] = $user['role'];

            if ($role === "admin") {
                header("Location: admin_dashboard.php");
            } else {
                header("Location: employee_dashboard.php");
            }
            exit();
        } else {
            $error = "Incorrect password.";
        }
    } else {
        $error = "Invalid login credentials.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--bg-color);
            color: var(--text-color);
            transition: all 0.3s ease;
        }

        :root {
            --bg-color: #ffffff;
            --container-bg: #f5f7fa;
            --primary: #406aff;
            --accent: #1b1f3b;
            --input-bg: #fff;
            --text-color: #1b1f3b;
        }

        body.dark {
            --bg-color: #1b1f3b;
            --container-bg: #2a2e4d;
            --primary: #64dfdf;
            --accent: #64dfdf;
            --input-bg: #1b1f3b;
            --text-color: #f5f7fa;
        }

        .login-container {
            background: var(--container-bg);
            padding: 40px;
            width: 100%;
            max-width: 430px;
            margin: 50px auto;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: var(--primary);
        }

        .input-group {
            position: relative;
            margin-bottom: 20px;
        }

        .input-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #aaa;
        }

        .input-group input,
        .input-group select {
            width: 100%;
            padding: 12px 15px 12px 42px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 14px;
            background-color: var(--input-bg);
            color: var(--text-color);
            outline: none;
        }

        .input-group input:focus,
        .input-group select:focus {
            border: 1px solid var(--accent);
            box-shadow: 0 0 8px var(--accent);
        }

        button {
            width: 100%;
            padding: 12px;
            border: none;
            background: var(--primary);
            color: white;
            font-size: 16px;
            font-weight: bold;
            border-radius: 8px;
            cursor: pointer;
        }

        button:hover {
            background: #3055d1;
        }

        .message {
            text-align: center;
            margin-top: 15px;
            font-weight: bold;
        }

        .message.success {
            color: #64df64;
        }

        .message.error {
            color: #ff6b6b;
        }

        .forgot-link, .switch-link {
            text-align: center;
            margin-top: 10px;
        }

        .forgot-link a,
        .switch-link a {
            text-decoration: none;
            color: var(--accent);
            font-weight: 500;
        }

        .forgot-link a:hover,
        .switch-link a:hover {
            text-decoration: underline;
        }

        .theme-toggle {
            position: absolute;
            top: 20px;
            right: 30px;
            font-size: 20px;
            cursor: pointer;
            color: var(--accent);
        }
    </style>
</head>
<body>

    <!-- Theme Toggle Button -->
    <div class="theme-toggle" onclick="toggleTheme()" title="Toggle theme">
        <i id="theme-icon" class="fas fa-moon"></i>
    </div>

    <div class="login-container">
        <h2><i class="fas fa-sign-in-alt"></i> Login</h2>

        <form method="POST">
            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" placeholder="Email" required>
            </div>

            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="Password" required>
            </div>

            <div class="input-group">
                <i class="fas fa-user-tag"></i>
                <select name="role" required>
                    <option value="">Select Role</option>
                    <option value="employee">Employee</option>
                    <option value="admin">Admin</option>
                </select>
            </div>

            <button type="submit">Login</button>

            <?php if ($error): ?>
                <div class="message error"><?= $error ?></div>
            <?php endif; ?>
        </form>

        <div class="forgot-link">
            <a href="#">Forgot Password?</a>
        </div>

        <div class="switch-link">
            Don't have an account? <a href="register.php">Register here</a>
        </div>
    </div>

    <script>
        // Theme toggle with localStorage
        function toggleTheme() {
            const body = document.body;
            const icon = document.getElementById("theme-icon");
            body.classList.toggle("dark");

            if (body.classList.contains("dark")) {
                localStorage.setItem("theme", "dark");
                icon.classList.replace("fa-moon", "fa-sun");
            } else {
                localStorage.setItem("theme", "light");
                icon.classList.replace("fa-sun", "fa-moon");
            }
        }

        // Load saved theme
        window.onload = () => {
            const savedTheme = localStorage.getItem("theme");
            const body = document.body;
            const icon = document.getElementById("theme-icon");

            if (savedTheme === "dark") {
                body.classList.add("dark");
                icon.classList.replace("fa-moon", "fa-sun");
            }
        };
    </script>

</body>
</html>
