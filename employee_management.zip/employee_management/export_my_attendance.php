<?php
session_start();
include 'db.php';

if (!isset($_SESSION['employee_id']) || $_SESSION['role'] !== 'employee') {
    header("Location: login.php");
    exit();
}

$employee_id = $_SESSION['employee_id'];

// Optional filter: this month only
$month = $_GET['month'] ?? null;
$year = $_GET['year'] ?? null;

if ($month && $year) {
    $query = "SELECT * FROM attendance WHERE employee_id='$employee_id' 
              AND MONTH(date) = '$month' AND YEAR(date) = '$year'
              ORDER BY date DESC";
    $filename = "attendance_{$year}_{$month}.csv";
} else {
    $query = "SELECT * FROM attendance WHERE employee_id='$employee_id' ORDER BY date DESC";
    $filename = "full_attendance.csv";
}

$result = mysqli_query($conn, $query);

// CSV headers
header('Content-Type: text/csv');
header("Content-Disposition: attachment; filename=$filename");

// Open output stream
$output = fopen("php://output", "w");

// Column headings
fputcsv($output, ['Date', 'Check-In', 'Check-Out', 'Working Hours', 'Status']);

// Write rows
while ($row = mysqli_fetch_assoc($result)) {
    fputcsv($output, [
        $row['date'],
        $row['check_in'] ?? '-',
        $row['check_out'] ?? '-',
        $row['working_hours'] ?? '-',
        $row['status'] ?? '-'
    ]);
}

fclose($output);
exit();
?>
