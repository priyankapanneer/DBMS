<?php
session_start();
if (!isset($_SESSION['employee_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

include 'db.php';

if (isset($_GET['id']) && isset($_GET['status'])) {
    $request_id = $_GET['id'];
    $status = $_GET['status'];

    // Validate the status
    if ($status != 'approved' && $status != 'rejected') {
        die('Invalid status');
    }

    // Update the status of the correction request
    $query = "UPDATE attendance_corrections SET status = '$status' WHERE id = $request_id";

    if (mysqli_query($conn, $query)) {
        header("Location: admin_attendance_corrections.php");
    } else {
        echo "Error updating status: " . mysqli_error($conn);
    }
} else {
    echo "Invalid request.";
}
?>
