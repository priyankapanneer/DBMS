<?php
include 'db.php';

function calculate_performance($employee_id) {
    global $conn;

    // Attendance performance
    $attendanceQuery = "SELECT COUNT(*) AS total_days, 
                        SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS days_present, 
                        SUM(CASE WHEN status = 'Late' THEN 1 ELSE 0 END) AS late_days
                        FROM attendance WHERE employee_id = $employee_id";
    $attendanceResult = mysqli_query($conn, $attendanceQuery);
    $attendanceData = mysqli_fetch_assoc($attendanceResult);

    // Leave performance
    $leaveQuery = "SELECT COUNT(*) AS total_leaves, 
                        SUM(CASE WHEN leave_type = 'Sick' AND status = 'Approved' THEN 1 ELSE 0 END) AS sick_leaves,
                        SUM(CASE WHEN leave_type = 'Casual' AND status = 'Approved' THEN 1 ELSE 0 END) AS casual_leaves
                        FROM leave_requests WHERE employee_id = $employee_id";
    $leaveResult = mysqli_query($conn, $leaveQuery);
    $leaveData = mysqli_fetch_assoc($leaveResult);

    return [
        'attendance' => $attendanceData,
        'leaves' => $leaveData
    ];
}

$selected_employee_id = isset($_GET['employee_id']) ? intval($_GET['employee_id']) : null;

// 👇 Only fetch employees who are not Admins
$employeesResult = mysqli_query($conn, "SELECT employee_id, name FROM employees WHERE role != 'Admin'");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Employee Performance</title>
    <style>
        body {
            font-family: 'Segoe UI';
            background: #f1f8e9;
            padding: 30px;
            text-align: center;
        }

        h2 {
            color: #33691e;
        }

        .form-box {
            margin: 20px auto;
        }

        select, button {
            padding: 10px 20px;
            margin: 10px;
            font-size: 16px;
            border-radius: 6px;
        }

        table {
            margin: 30px auto;
            border-collapse: collapse;
            width: 80%;
        }

        table, th, td {
            border: 1px solid #a5d6a7;
        }

        th, td {
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #aed581;
        }
    </style>
</head>
<body>
    <h2>📊 Employee Performance Report</h2>

    <form class="form-box" method="GET">
        <label for="employee_id">Select Employee:</label>
        <select name="employee_id" id="employee_id">
            <option value="">-- All Employees --</option>
            <?php while($row = mysqli_fetch_assoc($employeesResult)) { ?>
                <option value="<?= $row['employee_id'] ?>" <?= ($selected_employee_id == $row['employee_id']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($row['name']) ?>
                </option>
            <?php } ?>
        </select>
        <button type="submit">View Performance</button>
    </form>

    <?php
    if ($selected_employee_id) {
        $employeeQuery = mysqli_query($conn, "SELECT name FROM employees WHERE employee_id = $selected_employee_id AND role != 'Admin'");
        $employee = mysqli_fetch_assoc($employeeQuery);
        if ($employee) {
            $data = calculate_performance($selected_employee_id);
            ?>
            <h3>Performance for <?= htmlspecialchars($employee['name']) ?></h3>
            <table>
                <tr>
                    <th>Total Attendance Days</th>
                    <th>Days Present</th>
                    <th>Late Days</th>
                    <th>Total Leaves</th>
                    <th>Sick Leaves</th>
                    <th>Casual Leaves</th>
                </tr>
                <tr>
                    <td><?= $data['attendance']['total_days'] ?? 0 ?></td>
                    <td><?= $data['attendance']['days_present'] ?? 0 ?></td>
                    <td><?= $data['attendance']['late_days'] ?? 0 ?></td>
                    <td><?= $data['leaves']['total_leaves'] ?? 0 ?></td>
                    <td><?= $data['leaves']['sick_leaves'] ?? 0 ?></td>
                    <td><?= $data['leaves']['casual_leaves'] ?? 0 ?></td>
                </tr>
            </table>
        <?php
        } else {
            echo "<p>Invalid or unauthorized employee selected.</p>";
        }
    } elseif (isset($_GET['employee_id'])) {
        echo "<p>No employee selected or no data found.</p>";
    } else {
        echo "<p>Select an employee to view performance report.</p>";
    }
    ?>
</body>
</html>
