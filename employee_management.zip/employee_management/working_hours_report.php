<?php
include 'db.php';
date_default_timezone_set('Asia/Kolkata');

// Default to current month
$month = date('Y-m');
if (isset($_GET['month'])) {
    $month = $_GET['month'];
}

// Fetch daily working hours for the month
$query = "SELECT 
    a.employee_id,
    e.name AS employee_name,
    a.date,
    a.working_hours
FROM attendance a
JOIN employees e ON a.employee_id = e.id
WHERE a.date LIKE '$month%'
ORDER BY a.employee_id, a.date";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Working Hours Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            padding: 30px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .filter-box {
            text-align: center;
            margin-bottom: 20px;
        }
        .filter-box input {
            padding: 5px;
        }
        .filter-box button {
            padding: 6px 12px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
        }
        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: center;
        }
        .red {
            background-color: #ffcccc;
            color: #b30000;
            font-weight: bold;
        }
        .orange {
            background-color: #ffe0b3;
            color: #994d00;
            font-weight: bold;
        }
        .green {
            background-color: #ccffcc;
            color: #006600;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>🕒 Working Hours Report</h2>

<div class="filter-box">
    <form method="get">
        <label for="month">Select Month:</label>
        <input type="month" id="month" name="month" value="<?= $month ?>">
        <button type="submit">Filter</button>
    </form>
</div>

<table>
    <tr>
        <th>Employee ID</th>
        <th>Name</th>
        <th>Date</th>
        <th>Working Hours</th>
    </tr>

    <?php
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $hours = strtotime($row['working_hours']) - strtotime("00:00:00");
            $class = "";

            if ($hours < 4 * 3600) {
                $class = "red";
            } elseif ($hours < 8 * 3600) {
                $class = "orange";
            } else {
                $class = "green";
            }

            echo "<tr>
                <td>{$row['employee_id']}</td>
                <td>{$row['employee_name']}</td>
                <td>{$row['date']}</td>
                <td class='$class'>{$row['working_hours']}</td>
            </tr>";
        }
    } else {
        echo "<tr><td colspan='4'>No data found for the selected month.</td></tr>";
    }
    ?>
</table>

</body>
</html>
