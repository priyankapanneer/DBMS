<?php
session_start();
include 'db.php';

if (!isset($_SESSION['employee_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$result = mysqli_query($conn, "
    SELECT a.*, e.name FROM attendance a 
    JOIN employees e ON a.employee_id = e.employee_id  -- Updated column name here
    ORDER BY a.date DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Attendance Records</title>
    <style>
        body { font-family: 'Segoe UI'; background: #eef1f5; padding: 40px; }
        h2 { text-align: center; }
        table {
            width: 95%;
            margin: auto;
            border-collapse: collapse;
            background: white;
        }
        th, td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ccc;
        }
        th { background-color: #1565c0; color: white; }
        a.back { display: block; text-align: center; margin-top: 20px; color: #1976d2; }
    </style>
</head>
<body>
    <h2>Employee Attendance Records</h2>
    <table>
        <tr>
            <th>ID</th><th>Employee</th><th>Date</th><th>Check-In</th><th>Check-Out</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['name'] ?></td>
            <td><?= $row['date'] ?></td>
            <td><?= $row['check_in'] ?: '—' ?></td>
            <td><?= $row['check_out'] ?: '—' ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
    <a class="back" href="admin_dashboard.php">⬅ Back to Dashboard</a>
</body>
</html>
