<?php
include 'db.php';
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $new_password = password_hash($_POST["new_password"], PASSWORD_DEFAULT);

    $query = "UPDATE employees SET password='$new_password' WHERE email='$email'";
    if (mysqli_query($conn, $query)) {
        $message = "Password reset successful!";
    } else {
        $message = "Failed to reset password.";
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Forgot Password</title></head>
<body>
    <h2>Forgot Password</h2>
    <form method="POST">
        <input type="email" name="email" placeholder="Enter Email" required><br>
        <input type="password" name="new_password" placeholder="New Password" required><br>
        <button type="submit">Reset Password</button>
    </form>
    <?php if ($message): ?><p><?= $message ?></p><?php endif; ?>
</body>
</html>
