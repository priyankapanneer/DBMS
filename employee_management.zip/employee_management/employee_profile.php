<?php
session_start();
include 'db.php';

$employee_id = $_SESSION['employee_id'];

if (isset($_POST['update_profile'])) {
    $name = $_POST['name'];
    $query = "UPDATE employees SET name='$name' WHERE employee_id=$employee_id";
    mysqli_query($conn, $query);
    $success = "Profile updated successfully.";
}

if (isset($_POST['change_password'])) {
    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];

    $result = mysqli_query($conn, "SELECT password FROM employees WHERE employee_id=$employee_id");
    $row = mysqli_fetch_assoc($result);

    if ($row && $current === $row['password']) {
        if ($new === $confirm) {
            mysqli_query($conn, "UPDATE employees SET password='$new' WHERE employee_id=$employee_id");
            $success = "Password changed successfully.";
        } else {
            $error = "New passwords do not match.";
        }
    } else {
        $error = "Current password is incorrect.";
    }
}

$result = mysqli_query($conn, "SELECT * FROM employees WHERE employee_id=$employee_id");
$user = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Profile</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #d7e1ec;
            margin: 0;
            padding: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background: #ffffff;
            padding: 30px 40px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
            max-width: 500px;
            width: 100%;
        }

        h2 {
            color: #34495e;
            text-align: center;
            margin-bottom: 20px;
        }

        h3 {
            color: #2c3e50;
            margin-top: 30px;
            text-align: center;
        }

        input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #bdc3c7;
            border-radius: 8px;
            font-size: 14px;
            background-color: #f4f8fb;
        }

        input[readonly] {
            background-color: #ecf0f1;
        }

        .btn-center {
            display: flex;
            justify-content: center;
            margin-top: 15px;
        }

        button {
            padding: 12px 25px;
            background-color: #5c8dbc;
            color: #fff;
            font-size: 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background 0.3s;
        }

        button:hover {
            background-color: #3c6382;
        }

        .message {
            color: #2e7d32;
            margin-bottom: 10px;
            text-align: center;
        }

        .error {
            color: #c0392b;
            margin-bottom: 10px;
            text-align: center;
        }

        hr {
            border: none;
            height: 1px;
            background-color: #ddd;
            margin: 30px 0;
        }

        .back-btn {
            display: block;
            text-align: center;
            margin-top: 25px;
            text-decoration: none;
            color: #2980b9;
            font-weight: 500;
        }

        .back-btn:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>👤 My Profile</h2>

        <?php if (isset($success)) echo "<div class='message'>$success</div>"; ?>
        <?php if (isset($error)) echo "<div class='error'>$error</div>"; ?>

        <form method="POST">
            <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" placeholder="Full Name" required>
            <input type="email" value="<?= htmlspecialchars($user['email']) ?>" readonly>
            <div class="btn-center">
                <button type="submit" name="update_profile">Update Name</button>
            </div>
        </form>

        <hr>

        <h3>🔐 Change Password</h3>
        <form method="POST">
            <input type="password" name="current_password" placeholder="Current Password" required>
            <input type="password" name="new_password" placeholder="New Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm New Password" required>
            <div class="btn-center">
                <button type="submit" name="change_password">Change Password</button>
            </div>
        </form>

        <a class="back-btn" href="employee_dashboard.php">⬅ Back to Dashboard</a>
    </div>
</body>
</html>
