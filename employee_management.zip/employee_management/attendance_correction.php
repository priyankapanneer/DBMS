<?php
session_start();
if (!isset($_SESSION['employee_id']) || $_SESSION['role'] !== 'employee') {
    header("Location: login.php");
    exit();
}

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect form data
    $emp_id = $_SESSION['employee_id'];
    $correction_date = mysqli_real_escape_string($conn, $_POST['correction_date']);
    $correction_reason = mysqli_real_escape_string($conn, $_POST['correction_reason']);

    // Insert correction request into the database
    $query = "INSERT INTO attendance_corrections (employee_id, correction_date, correction_reason, status) 
              VALUES ('$emp_id', '$correction_date', '$correction_reason', 'pending')";

    if (mysqli_query($conn, $query)) {
        // Show a success message and redirect back to the employee dashboard
        echo "<script>alert('Your correction request has been submitted!'); window.location.href='employee_dashboard.php';</script>";
    } else {
        // Show an error message if the query fails
        echo "<script>alert('Error submitting your request. Please try again later.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Correction Request</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap">
    <style>
        /* Same styles as in the dashboard for consistency */
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #333;
        }

        .correction-form {
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
            width: 60%;
            max-width: 800px;
            padding: 40px;
            text-align: center;
            margin: 30px auto;
            box-sizing: border-box;
        }

        .correction-form h2 {
            font-weight: 600;
            color: #007bff;
            margin-bottom: 30px;
        }

        .correction-form input,
        .correction-form textarea {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        .correction-form button {
            background-color: #28a745;
            color: white;
            padding: 14px 20px;
            border-radius: 8px;
            font-size: 16px;
            width: 100%;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .correction-form button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="correction-form">
        <h2>📋 Request Attendance Correction</h2>
        <form action="attendance_correction.php" method="POST">
            <input type="date" name="correction_date" placeholder="Select Date of Correction" required>
            <textarea name="correction_reason" placeholder="Reason for Correction" rows="4" required></textarea>
            <button type="submit">Submit Correction Request</button>
        </form>
    </div>
</body>
</html>
