<?php
include 'db.php';

// --- Total employees (excluding admin) ---
$empResult = mysqli_query($conn, "SELECT COUNT(*) as total FROM employees WHERE role != 'admin'");
$employeeCount = mysqli_fetch_assoc($empResult)['total'];

// --- Present today ---
$today = date('Y-m-d');
$presentResult = mysqli_query($conn, "SELECT COUNT(DISTINCT employee_id) as present FROM attendance WHERE DATE(check_in) = '$today'");
$presentCount = mysqli_fetch_assoc($presentResult)['present'];
$absentCount = $employeeCount - $presentCount;

// --- Leave requests status ---
$leaveResult = mysqli_query($conn, "SELECT status, COUNT(*) as count FROM leave_requests GROUP BY status");
$leaveStats = ['Approved' => 0, 'Rejected' => 0];
while ($row = mysqli_fetch_assoc($leaveResult)) {
    $leaveStats[$row['status']] = $row['count'];
}

// --- Attendance trend last 7 days ---
$trendLabels = [];
$trendData = [];
for ($i = 6; $i >= 0; $i--) {
    $day = date('Y-m-d', strtotime("-$i days"));
    $trendLabels[] = $day;
    $result = mysqli_query($conn, "SELECT COUNT(DISTINCT employee_id) as count FROM attendance WHERE DATE(check_in) = '$day'");
    $data = mysqli_fetch_assoc($result);
    $trendData[] = $data['count'];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard Analytics</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: 'Segoe UI';
            background: #f5f8fd;
            padding: 40px;
            text-align: center;
        }
        h2 {
            color: #1a237e;
        }
        .chart-container {
            width: 90%;
            margin: 40px auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        canvas {
            max-width: 800px;
            margin: 20px auto;
        }
    </style>
</head>
<body>

<h2>📊 Admin Dashboard Analytics</h2>

<div class="chart-container">
    <h3>🟢 Attendance Today (Present vs Absent)</h3>
    <canvas id="pieChart"></canvas>
</div>

<div class="chart-container">
    <h3>📄 Leave Requests (Approved vs Rejected)</h3>
    <canvas id="barChart"></canvas>
</div>

<div class="chart-container">
    <h3>📈 Attendance Trend (Last 7 Days)</h3>
    <canvas id="lineChart"></canvas>
</div>

<script>
    const pieCtx = document.getElementById('pieChart').getContext('2d');
    new Chart(pieCtx, {
        type: 'pie',
        data: {
            labels: ['Present', 'Absent'],
            datasets: [{
                label: 'Today\'s Attendance',
                data: [<?= $presentCount ?>, <?= $absentCount ?>],
                backgroundColor: ['#66bb6a', '#ef5350']
            }]
        }
    });

    const barCtx = document.getElementById('barChart').getContext('2d');
    new Chart(barCtx, {
        type: 'bar',
        data: {
            labels: ['Approved', 'Rejected'],
            datasets: [{
                label: 'Leave Requests',
                data: [<?= $leaveStats['Approved'] ?>, <?= $leaveStats['Rejected'] ?>],
                backgroundColor: ['#42a5f5', '#ef5350']
            }]
        },
        options: {
            scales: {
                y: { beginAtZero: true }
            }
        }
    });

    const lineCtx = document.getElementById('lineChart').getContext('2d');
    new Chart(lineCtx, {
        type: 'line',
        data: {
            labels: <?= json_encode($trendLabels) ?>,
            datasets: [{
                label: 'Employees Present',
                data: <?= json_encode($trendData) ?>,
                backgroundColor: 'rgba(33, 150, 243, 0.2)',
                borderColor: '#2196f3',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
</script>

</body>
</html>
