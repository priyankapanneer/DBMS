<?php
session_start();
include 'db.php';

if (!isset($_SESSION['employee_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$result = mysqli_query($conn, "SELECT * FROM employees");
?>

<!DOCTYPE html>
<html>
<head>
    <title>All Employees</title>
    <style>
        body { font-family: 'Segoe UI'; background: #f4f7f8; padding: 40px; }
        h2 { text-align: center; }
        table {
            width: 90%;
            margin: auto;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }
        th { background-color: #1976d2; color: white; }
        tr:hover { background-color: #f1f1f1; }
        a.back { display: block; text-align: center; margin-top: 20px; color: #1976d2; }
    </style>
</head>
<body>
    <h2>All Employees</h2>
    <table>
        <tr>
            <th>ID</th><th>Name</th><th>Email</th><th>Date of Joining</th><th>Role</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <!-- Use employee_id instead of id if that's the correct column name -->
            <td><?= $row['employee_id'] ?></td>  <!-- Updated column name here -->
            <td><?= $row['name'] ?></td>
            <td><?= $row['email'] ?></td>
            <td><?= $row['date_of_joining'] ?></td>
            <td><?= ucfirst($row['role']) ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
    <a class="back" href="admin_dashboard.php">⬅ Back to Dashboard</a>
</body>
</html>
