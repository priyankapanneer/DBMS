<?php
session_start();
include 'db.php';

if (!isset($_SESSION['employee_id']) || $_SESSION['role'] !== 'employee') {
    header("Location: login.php");
    exit();
}

date_default_timezone_set('Asia/Kolkata');
$employee_id = $_SESSION['employee_id'];
$date = date('Y-m-d');
$check_in_time = date('Y-m-d H:i:s');

$query = "SELECT * FROM attendance WHERE employee_id='$employee_id' AND date='$date'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) == 0) {
    $insert = "INSERT INTO attendance (employee_id, date, check_in) VALUES ('$employee_id', '$date', '$check_in_time')";
    if (mysqli_query($conn, $insert)) {
        $status = "success";
        $message = "✅ Checked in successfully at $check_in_time";
    } else {
        $status = "error";
        $message = "❌ Error during check-in. Please try again.";
    }
} else {
    $status = "warning";
    $message = "⚠️ You have already checked in today.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Check-In</title>
    <style>
        :root {
            --bg-light: #f0f4f8;
            --text-light: #333;
            --card-light: #ffffff;

            --bg-dark: #1e1e2f;
            --text-dark: #f5f5f5;
            --card-dark: #2d2d44;

            --success: #28a745;
            --warning: #ffc107;
            --error: #dc3545;
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: var(--bg-light);
            color: var(--text-light);
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            transition: all 0.3s ease;
        }

        body.dark-mode {
            background-color: var(--bg-dark);
            color: var(--text-dark);
        }

        .box {
            background-color: var(--card-light);
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.1);
            text-align: center;
            width: 400px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        body.dark-mode .box {
            background-color: var(--card-dark);
        }

        .success { color: var(--success); }
        .warning { color: var(--warning); }
        .error { color: var(--error); }

        a {
            margin-top: 20px;
            display: inline-block;
            text-decoration: none;
            color: inherit;
            font-weight: bold;
            border: 2px solid #007bff;
            padding: 10px 20px;
            border-radius: 10px;
            transition: all 0.3s;
        }

        a:hover {
            background-color: #007bff;
            color: white;
        }

        .theme-toggle {
            position: absolute;
            top: 20px;
            right: 20px;
            cursor: pointer;
            font-size: 16px;
            background: none;
            border: none;
            font-weight: bold;
            color: inherit;
        }
    </style>
</head>
<body>
    <button class="theme-toggle" onclick="toggleTheme()">🌓 Toggle Theme</button>
    <div class="box">
        <h2 class="<?= $status ?>"><?= $message ?></h2>
        <a href="employee_dashboard.php">⬅ Back to Dashboard</a>
    </div>

    <script>
        function toggleTheme() {
            document.body.classList.toggle('dark-mode');
            localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        }

        // Persist theme
        window.onload = () => {
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                document.body.classList.add('dark-mode');
            }
        };
    </script>
</body>
</html>
