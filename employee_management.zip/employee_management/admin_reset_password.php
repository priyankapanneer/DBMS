<?php
session_start();
include 'db.php';

if (!isset($_SESSION['employee_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$msg = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $employee_id = $_POST['employee_id'];
    $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

    $update = mysqli_query($conn, "UPDATE employees SET password='$new_password' WHERE id='$employee_id'");

    $msg = $update ? "Password reset successfully!" : "Failed to reset password.";
}

$employees = mysqli_query($conn, "SELECT id, name, email FROM employees");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reset Employee Password</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f3f4f6;
            padding: 40px;
        }

        .container {
            max-width: 500px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 12px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-top: 10px;
        }

        select, input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 10px;
            border: 1px solid #ccc;
        }

        button {
            margin-top: 20px;
            width: 100%;
            padding: 10px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 10px;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background: #218838;
        }

        .msg {
            text-align: center;
            margin-top: 10px;
            color: green;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>🔐 Reset Employee Password</h2>
        <form method="POST">
            <label>Select Employee</label>
            <select name="employee_id" required>
                <option value="">Select</option>
                <?php while($emp = mysqli_fetch_assoc($employees)): ?>
                    <option value="<?= $emp['id'] ?>">
                        <?= $emp['name'] ?> (<?= $emp['email'] ?>)
                    </option>
                <?php endwhile; ?>
            </select>

            <label>New Password</label>
            <input type="password" name="new_password" required>

            <button type="submit">Reset Password</button>
        </form>
        <?php if ($msg): ?>
            <p class="msg"><?= $msg ?></p>
        <?php endif; ?>
    </div>
</body>
</html>
