<?php
session_start();
if (!isset($_SESSION['employee_id']) || $_SESSION['role'] !== 'employee') {
    header("Location: login.php");
    exit();
}
include 'db.php';
$employee_id = $_SESSION['employee_id'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Leave History</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #ece9e6, #ffffff);
            padding: 30px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        .leave-history {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        .status-pending {
            color: orange;
            font-weight: bold;
        }

        .status-approved {
            color: green;
            font-weight: bold;
        }

        .status-rejected {
            color: red;
            font-weight: bold;
        }

        a.back-btn {
            display: inline-block;
            margin-bottom: 15px;
            background: #007bff;
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
            text-decoration: none;
        }

        a.back-btn:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>

<div class="leave-history">
    <a href="employee_dashboard.php" class="back-btn">⬅ Back to Dashboard</a>
    <h2>📖 My Leave History</h2>

    <table>
        <tr>
            <th>From Date</th>
            <th>To Date</th>
            <th>Reason</th>
            <th>Status</th>
            <th>Submitted On</th>
        </tr>

        <?php
        $query = "SELECT * FROM leave_requests WHERE employee_id = '$employee_id' ORDER BY submitted_at DESC";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $status_class = 'status-pending';
                if ($row['status'] === 'approved') $status_class = 'status-approved';
                else if ($row['status'] === 'rejected') $status_class = 'status-rejected';

                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['from_date']) . "</td>";
                echo "<td>" . htmlspecialchars($row['to_date']) . "</td>";
                echo "<td>" . htmlspecialchars($row['reason']) . "</td>";
                echo "<td class='$status_class'>" . ucfirst($row['status']) . "</td>";
                echo "<td>" . htmlspecialchars($row['submitted_at']) . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No leave requests found.</td></tr>";
        }
        ?>
    </table>
</div>

</body>
</html>
