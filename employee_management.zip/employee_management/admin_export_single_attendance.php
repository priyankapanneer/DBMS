<?php
session_start();

// Ensure the user is an Admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

include('db.php'); // Ensure your DB connection file is included

// Get the list of employees from the database
$employees_query = "SELECT employee_id, employee_name FROM employees";
$employees_result = mysqli_query($conn, $employees_query);

// Handle form submission to view selected employee's attendance with date range and sorting
$attendance_data = null;
$start_date = $end_date = '';
$order_by = 'date DESC';  // Default sorting by date descending

if (isset($_POST['employee_id'])) {
    $employee_id = $_POST['employee_id'];

    // Handle date range filter
    if (isset($_POST['start_date']) && isset($_POST['end_date'])) {
        $start_date = $_POST['start_date'];
        $end_date = $_POST['end_date'];
        $date_filter = "AND date BETWEEN '$start_date' AND '$end_date'";
    } else {
        $date_filter = '';
    }

    // Handle sorting
    if (isset($_POST['sort_order'])) {
        $order_by = $_POST['sort_order'];
    }

    // Query attendance records for the selected employee with date filter and sorting
    $attendance_query = "SELECT * FROM attendance WHERE employee_id = '$employee_id' $date_filter ORDER BY $order_by";
    $attendance_result = mysqli_query($conn, $attendance_query);

    if (mysqli_num_rows($attendance_result) > 0) {
        $attendance_data = mysqli_fetch_all($attendance_result, MYSQLI_ASSOC);
    } else {
        $attendance_data = [];
    }
}

// Export CSV functionality
if (isset($_POST['export_csv'])) {
    if (!empty($attendance_data)) {
        // Set the header for CSV file download
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="attendance_records.csv"');
        
        $output = fopen('php://output', 'w');
        
        // Add column headings
        fputcsv($output, ['Date', 'Status', 'Check-in Time', 'Check-out Time']);
        
        // Add rows
        foreach ($attendance_data as $attendance) {
            fputcsv($output, $attendance);
        }

        fclose($output);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Employee Attendance</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            display: flex;
            background: #f4f6f7;
        }

        .sidebar {
            background-color: #34495e;
            width: 250px;
            height: 100vh;
            padding-top: 40px;
            position: fixed;
        }

        .sidebar h2 {
            color: #ecf0f1;
            text-align: center;
            margin-bottom: 30px;
        }

        .sidebar a {
            display: block;
            color: #bdc3c7;
            padding: 15px;
            text-decoration: none;
            font-weight: bold;
            margin: 10px 0;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #16a085;
            color: white;
        }

        .main-content {
            margin-left: 260px;
            padding: 30px;
            background-color: #ecf0f1;
            height: 100vh;
            width: calc(100% - 250px);
            overflow: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #2c3e50;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .logout {
            margin-top: 40px;
            display: inline-block;
            background: #e74c3c;
            color: white;
            padding: 10px 25px;
            border-radius: 8px;
            text-decoration: none;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .btn-submit {
            background-color: #2980b9;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        
        .btn-submit:hover {
            background-color: #3498db;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Admin Dashboard</h2>
        <a href="admin_view_employees.php">👨‍💼 View Employees</a>
        <a href="admin_manage_employees.php">🛠️ Manage Employees</a>
        <a href="admin_leave_requests.php">📄 Manage Leave Requests</a>
        <a href="admin_attendance_records.php">📅 View Attendance Records</a>
        <a href="admin_dashboard_analytics.php">📊 Dashboard Analytics</a>
        <a href="admin_export_attendance.php">📁 Export Attendance as CSV</a>
        <a href="admin_export_single_attendance.php">📤 Selected Employee Attendance</a>
        <a href="admin_notifications.php">🔔 View Notifications</a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <h2>View Employee Attendance</h2>

        <!-- Employee Selection Form -->
        <form method="POST" action="">
            <div class="form-group">
                <label for="employee_id">Select Employee:</label>
                <select name="employee_id" id="employee_id" required>
                    <option value="">Select Employee</option>
                    <?php
                    while ($employee = mysqli_fetch_assoc($employees_result)) {
                        echo "<option value='{$employee['employee_id']}'>{$employee['employee_name']}</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- Date Range Filter -->
            <div class="form-group">
                <label for="start_date">Start Date:</label>
                <input type="date" name="start_date" value="<?php echo $start_date; ?>">

                <label for="end_date">End Date:</label>
                <input type="date" name="end_date" value="<?php echo $end_date; ?>">
            </div>

            <!-- Sorting Options -->
            <div class="form-group">
                <label for="sort_order">Sort By:</label>
                <select name="sort_order" id="sort_order">
                    <option value="date DESC" <?php if ($order_by == 'date DESC') echo 'selected'; ?>>Date (Newest)</option>
                    <option value="date ASC" <?php if ($order_by == 'date ASC') echo 'selected'; ?>>Date (Oldest)</option>
                </select>
            </div>

            <button type="submit" class="btn-submit">View Attendance</button>
            <button type="submit" name="export_csv" class="btn-submit" style="background-color: #e67e22;">Export to CSV</button>
        </form>

        <?php if ($attendance_data !== null): ?>
            <h3>Attendance Records</h3>
            <?php if (count($attendance_data) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Check-in Time</th>
                            <th>Check-out Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($attendance_data as $attendance): ?>
                            <tr>
                                <td><?php echo $attendance['date']; ?></td>
                                <td><?php echo $attendance['status']; ?></td>
                                <td><?php echo $attendance['check_in_time']; ?></td>
                                <td><?php echo $attendance['check_out_time']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No attendance records found for the selected employee.</p>
            <?php endif; ?>
        <?php endif; ?>

        <a class="logout" href="logout.php">🚪 Logout</a>
    </div>

</body>
</html>
